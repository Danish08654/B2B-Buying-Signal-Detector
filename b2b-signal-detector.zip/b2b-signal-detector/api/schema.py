from pydantic import BaseModel, Field
from typing import Optional

class CompanySignals(BaseModel):
    industry: str = Field(..., description="Company industry vertical")
    company_size: str = Field(..., description="Employee count range")
    new_job_postings_30d: int = Field(..., ge=0)
    hiring_sales_marketing: int = Field(..., ge=0, le=1)
    hiring_engineers: int = Field(..., ge=0, le=1)
    job_posting_growth_rate: float = Field(..., ge=-1, le=3)
    days_since_funding: int = Field(..., ge=0)
    funding_amount_m: float = Field(..., ge=0)
    funding_round: int = Field(..., ge=0, le=4,
        description="0=none 1=seed 2=A 3=B 4=C+")
    new_tools_added_90d: int = Field(..., ge=0)
    using_competitor: int = Field(..., ge=0, le=1)
    tech_stack_size: int = Field(..., ge=1)
    web_traffic_growth_pct: float
    linkedin_follower_growth: float
    news_mentions_30d: int = Field(..., ge=0)
    has_recent_announcement: int = Field(..., ge=0, le=1)
    visited_pricing_page: int = Field(..., ge=0, le=1)
    email_engagement_score: float = Field(..., ge=0, le=1)
    days_since_last_touch: int = Field(..., ge=0)
    company_name: Optional[str] = None

class IntentScore(BaseModel):
    company_name: str
    intent_score: float
    intent_tier: str
    decision: str
    top_buying_signals: list
    top_missing_signals: list
    recommended_action: str