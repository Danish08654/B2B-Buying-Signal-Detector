import json
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from schema import CompanySignals, IntentScore


app = FastAPI(
    title="B2B Buying Signal Detector",
    description="Predict which companies are in active buying mode",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Load at startup — native XGBoost format (version-safe)
model = xgb.XGBClassifier()
model.load_model("b2b_intent_model.json")

le_industry = joblib.load("le_industry.joblib")
le_size     = joblib.load("le_size.joblib")

with open("b2b_metadata.json") as f:
    metadata = json.load(f)

FEATURES  = metadata["features"]
THRESHOLD = metadata["threshold"]


def encode_and_engineer(data: dict) -> pd.DataFrame:
    df = pd.DataFrame([data])

    # Encode categoricals safely
    industry = data['industry'] if data['industry'] in metadata['industries'] else metadata['industries'][0]
    size     = data['company_size'] if data['company_size'] in metadata['company_sizes'] else metadata['company_sizes'][0]

    df['industry_enc'] = le_industry.transform([industry])[0]
    df['size_enc']     = le_size.transform([size])[0]

    # Engineered features
    df['funding_recency_score'] = np.where(
        df['days_since_funding'] == 0, 0,
        1 / (df['days_since_funding'] + 1) * df['funding_amount_m']
    )
    df['hiring_momentum'] = (
        df['new_job_postings_30d'] *
        (1 + df['job_posting_growth_rate'].clip(0, 2)) *
        (1 + df['hiring_sales_marketing'] * 0.5)
    )
    df['tech_expansion_signal'] = (
        df['new_tools_added_90d'] * (df['tech_stack_size'] / 50)
    )
    df['digital_growth_composite'] = (
        df['web_traffic_growth_pct'].clip(-50, 100) / 100 +
        df['linkedin_follower_growth'].clip(-20, 50) / 50
    ) / 2
    df['engagement_recency'] = (
        df['email_engagement_score'] *
        (1 - df['days_since_last_touch'] / 365)
    )
    df['announcement_boost'] = (
        df['has_recent_announcement'] * df['news_mentions_30d']
    )

    return df[FEATURES]


def get_feature_contributions(X: pd.DataFrame) -> list:
    """
    XGBoost native SHAP-like contribution scores.
    No SHAP library needed — XGBoost computes this internally.
    Last column is the bias term — excluded.
    """
    dmatrix  = xgb.DMatrix(X, feature_names=FEATURES)
    contribs = model.get_booster().predict(dmatrix, pred_contribs=True)
    # Shape: (1, n_features + 1) — drop last bias column
    feature_contribs = contribs[0][:-1]
    return list(zip(FEATURES, feature_contribs))


def get_tier(score: float) -> str:
    if score >= 0.75: return "Hot"
    if score >= 0.55: return "Warm"
    if score >= 0.35: return "Lukewarm"
    return "Cold"


def get_action(tier: str) -> str:
    actions = {
        "Hot":      "Assign AE immediately — reach out within 24 hours",
        "Warm":     "Add to active sequence — personalised outreach this week",
        "Lukewarm": "Nurture campaign — add to email sequence",
        "Cold":     "Monitor only — re-evaluate in 30 days"
    }
    return actions[tier]


@app.get("/")
def root():
    return {
        "service": "B2B Buying Signal Detector",
        "version": metadata["version"],
        "model_auc": metadata["model_auc"]
    }


@app.post("/score", response_model=IntentScore)
def score_company(company: CompanySignals):
    try:
        input_dict   = company.model_dump()
        company_name = input_dict.pop("company_name") or "Unknown Company"

        X = encode_and_engineer(input_dict)

        # Predict probability
        intent_score = float(model.predict_proba(X)[0][1])
        tier         = get_tier(intent_score)
        decision     = "IN MARKET" if intent_score >= THRESHOLD else "NOT IN MARKET"

        # Feature contributions — XGBoost native, no SHAP library
        contrib_pairs   = get_feature_contributions(X)
        sorted_contribs = sorted(contrib_pairs, key=lambda x: abs(x[1]), reverse=True)

        buying_signals  = [{"signal": f, "strength": round(float(v), 4)}
                           for f, v in sorted_contribs if v > 0][:4]
        missing_signals = [{"signal": f, "gap": round(float(abs(v)), 4)}
                           for f, v in sorted_contribs if v < 0][:3]

        return IntentScore(
            company_name=company_name,
            intent_score=round(intent_score, 4),
            intent_tier=tier,
            decision=decision,
            top_buying_signals=buying_signals,
            top_missing_signals=missing_signals,
            recommended_action=get_action(tier)
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/tiers")
def tier_info():
    return metadata["intent_tiers"]


@app.get("/model/info")
def model_info():
    return metadata